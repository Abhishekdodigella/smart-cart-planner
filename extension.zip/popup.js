document.getElementById('scrapeBtn').addEventListener('click', async () => {
    const btn = document.getElementById('scrapeBtn');
    btn.disabled = true;
    btn.innerText = "Scanning...";

    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => {
            const items = [];
            // We search for everything that might contain a product
            // Targetting standard Amazon classes AND generic list items
            const potentialItems = document.querySelectorAll('.sc-list-item, .sc-card-container, .a-row.sc-list-item-content');
            
            potentialItems.forEach(el => {
                const text = el.innerText;
                // Regex: Find Rupee symbol followed by numbers (handles commas/decimals)
                const priceMatch = text.match(/(?:₹|Rs\.?|INR)\s?([\d,]+(?:\.\d{2})?)/);
                
                if (priceMatch) {
                    // Title Logic: Usually the first 2 lines of text contain the name
                    let lines = text.split('\n').filter(l => l.trim().length > 0);
                    let name = lines[0]; 
                    
                    // If the first line is just "Qty" or a checkbox, take the next one
                    if (name.length < 5 && lines.length > 1) name = lines[1];

                    let price = parseInt(priceMatch[1].replace(/,/g, ''));

                    // Ensure it's not a tiny price (like a discount alert)
                    if (price > 10 && !items.find(i => i.name === name)) {
                        items.push({
                            name: name.trim().substring(0, 60),
                            price: price,
                            site: "Amazon"
                        });
                    }
                }
            });
            return items;
        }
    }, (results) => {
        const found = results[0].result;
        
        if (!found || found.length === 0) {
            alert("Amazon is hiding the data! Please scroll down so your items are fully visible on screen and try again.");
            btn.disabled = false;
            btn.innerText = "Analyze My Cart";
        } else {
            const data = encodeURIComponent(JSON.stringify(found));
            const url = `https://smart-cart-planner-fhpdbccnhemsaxco3dwpjw.streamlit.app/?cart_data=${data}`;
            chrome.tabs.create({ url: url });
            btn.disabled = false;
            btn.innerText = "Analyze My Cart";
        }
    });
});