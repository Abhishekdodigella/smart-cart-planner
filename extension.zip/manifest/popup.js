document.getElementById('scrapeBtn').addEventListener('click', async () => {
    const btn = document.getElementById('scrapeBtn');
    btn.disabled = true;
    btn.innerText = "Scanning...";

    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: async () => {
            // Force lazy items to load
            window.scrollTo(0, 500);
            await new Promise(r => setTimeout(r, 400));
            window.scrollTo(0, 0);

            const items = [];
            // Specific Amazon Indian Store tags
            const products = document.querySelectorAll('.sc-list-item, .sc-card-container, [data-asin]');
            
            products.forEach(p => {
                const text = p.innerText;
                const priceMatch = text.match(/(?:₹|Rs\.?|INR)\s?([\d,]+)/);
                if (priceMatch) {
                    let titleEl = p.querySelector('.sc-product-title, .a-truncate-cut');
                    items.push({
                        name: titleEl ? titleEl.innerText.trim().substring(0, 50) : "Product",
                        price: parseInt(priceMatch[1].replace(/,/g, '')),
                        site: "Amazon"
                    });
                }
            });
            return items;
        }
    }, (results) => {
        const found = results[0].result;
        if (!found || found.length === 0) {
            alert("Amazon is hiding items! Scroll down and try again.");
            btn.disabled = false;
        } else {
            const data = encodeURIComponent(JSON.stringify(found));
            chrome.tabs.create({ url: `https://smart-cart-planner-fhpdbccnhemsaxco3dwpjw.streamlit.app/?cart_data=${data}` });
        }
    });
});