document.getElementById('scrapeBtn').addEventListener('click', async () => {
    const btn = document.getElementById('scrapeBtn');
    btn.disabled = true;
    btn.innerText = "Scanning...";

    let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: async () => {
            // Auto-scroll to trigger Amazon's lazy loading
            window.scrollTo(0, document.body.scrollHeight / 2);
            await new Promise(r => setTimeout(r, 500)); 
            window.scrollTo(0, 0);

            const items = [];
            // Target containers: Amazon (sc-list-item), Myntra (cart-item), Flipkart (_2n_9y_)
            const products = document.querySelectorAll('.sc-list-item, .sc-card-container, [data-asin], .cart-item, ._2n_9y_');
            
            products.forEach(p => {
                const text = p.innerText;
                const priceMatch = text.match(/(?:₹|Rs\.?|INR)\s?([\d,]+(?:\.\d{2})?)/);
                
                if (priceMatch) {
                    let titleEl = p.querySelector('.sc-product-title, .a-truncate-cut, h2, .item-title');
                    let name = titleEl ? titleEl.innerText.trim() : text.split('\n')[0].trim();

                    if (name.length > 5 && !name.toLowerCase().includes("subtotal")) {
                        items.push({
                            name: name.substring(0, 60),
                            price: parseInt(priceMatch[1].replace(/,/g, '')),
                            site: window.location.hostname
                        });
                    }
                }
            });
            return items;
        }
    }, (results) => {
        const found = results[0].result;
        if (!found || found.length === 0) {
            alert("Nothing found! Make sure you are on the Cart page and scroll down slightly to reveal items.");
            btn.disabled = false;
            btn.innerText = "Analyze My Cart";
        } else {
            const data = encodeURIComponent(JSON.stringify(found));
            // Ensure this matches your LIVE streamlit URL
            const url = `https://smart-cart-planner-fhpdbccnhemsaxco3dwpjw.streamlit.app/?cart_data=${data}`;
            chrome.tabs.create({ url: url });
            btn.disabled = false;
            btn.innerText = "Analyze My Cart";
        }
    });
});