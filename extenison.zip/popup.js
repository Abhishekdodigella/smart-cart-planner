document.getElementById('scrape').addEventListener('click', async () => {
    const btn = document.getElementById('scrape');
    btn.disabled = true;
    btn.innerText = "Scanning...";

    try {
        let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

        chrome.scripting.executeScript({
            target: { tabId: tab.id },
            func: () => {
                const items = [];
                // Look for any div that looks like a product (Universal Scraper)
                const blocks = document.querySelectorAll('div');
                blocks.forEach(el => {
                    if (el.innerText.length > 300 || el.innerText.length < 20) return;
                    const text = el.innerText;
                    const priceMatch = text.match(/(?:₹|Rs\.?|INR)\s?([\d,]+)/);
                    
                    if (priceMatch) {
                        let name = text.split('\n')[0].trim();
                        let price = parseInt(priceMatch[1].replace(/,/g, ''));
                        if (name.length > 3 && price > 0 && !items.find(i => i.name === name)) {
                            items.push({
                                name: name.substring(0, 50),
                                price: price,
                                site: window.location.hostname
                            });
                        }
                    }
                });
                return items;
            }
        }, (results) => {
            if (!results || !results[0].result || results[0].result.length === 0) {
                alert("No items found. Make sure you are on the Cart page!");
                btn.disabled = false;
                btn.innerText = "Analyze My Cart";
                return;
            }

            const data = encodeURIComponent(JSON.stringify(results[0].result));
            const url = `https://smart-cart-planner-fhpdbccnhemsaxco3dwpjw.streamlit.app/?cart_data=${data}`;
            chrome.tabs.create({ url: url });
            
            btn.disabled = false;
            btn.innerText = "Analyze My Cart";
        });
    } catch (err) {
        console.error(err);
        btn.disabled = false;
        btn.innerText = "Analyze My Cart";
    }
});